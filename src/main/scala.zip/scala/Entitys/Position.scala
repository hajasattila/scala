package Entitys

/**
 * Pozicíó
 * @param x x koordintája
 * @param y y koordinátája
 */
case class Position(x: Double, y: Double)
